<?php
/**
 * Plugin Name: WP Admin Taxonomy Inline Dropdown
 * Description: Permite asignar terminos de una taxonomia desde la columna del listado de entradas (sin Quick Edit), configurable por tipo de post.
 * Version: 1.0.0
 * Author: Book Uploader
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'WP_Admin_Taxonomy_Inline_Dropdown' ) ) {
    class WP_Admin_Taxonomy_Inline_Dropdown {
        const OPTION_KEY = 'watid_post_type_taxonomy_map';
        const NONCE_ACTION_SAVE = 'watid_save_inline_term';
        const NONCE_ACTION_FETCH = 'watid_fetch_inline_terms';

        public function __construct() {
            add_action( 'admin_menu', array( $this, 'register_settings_page' ) );
            add_action( 'admin_init', array( $this, 'register_settings' ) );

            add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );

            add_action( 'wp_ajax_watid_get_current_terms', array( $this, 'ajax_get_current_terms' ) );
            add_action( 'wp_ajax_watid_set_term', array( $this, 'ajax_set_term' ) );
        }

        public function register_settings_page() {
            add_options_page(
                'Taxonomy Inline Dropdown',
                'Taxonomy Inline Dropdown',
                'manage_options',
                'watid-settings',
                array( $this, 'render_settings_page' )
            );
        }

        public function register_settings() {
            register_setting(
                'watid_settings_group',
                self::OPTION_KEY,
                array( $this, 'sanitize_settings' )
            );

            add_settings_section(
                'watid_main_section',
                'Configuracion de dropdown en columnas',
                function() {
                    echo '<p>Selecciona para cada tipo de post la taxonomia que se podra editar desde la columna del listado. Solo aparecen taxonomias con <code>show_admin_column</code> activado.</p>';
                },
                'watid-settings'
            );

            add_settings_field(
                'watid_mapping_field',
                'Asignacion por tipo de post',
                array( $this, 'render_mapping_field' ),
                'watid-settings',
                'watid_main_section'
            );
        }

        public function sanitize_settings( $input ) {
            $clean = array();
            $input = is_array( $input ) ? $input : array();

            $post_types = get_post_types( array( 'show_ui' => true ), 'names' );

            foreach ( $input as $post_type => $taxonomy ) {
                $post_type = sanitize_key( $post_type );
                $taxonomy = sanitize_key( $taxonomy );

                if ( ! in_array( $post_type, $post_types, true ) ) {
                    continue;
                }

                if ( empty( $taxonomy ) ) {
                    continue;
                }

                $tax_obj = get_taxonomy( $taxonomy );
                if ( ! $tax_obj ) {
                    continue;
                }

                if ( empty( $tax_obj->show_admin_column ) ) {
                    continue;
                }

                if ( ! is_object_in_taxonomy( $post_type, $taxonomy ) ) {
                    continue;
                }

                $clean[ $post_type ] = $taxonomy;
            }

            return $clean;
        }

        public function render_mapping_field() {
            $saved = $this->get_mapping();
            $post_types = get_post_types( array( 'show_ui' => true ), 'objects' );

            echo '<table class="widefat striped" style="max-width: 900px">';
            echo '<thead><tr><th>Tipo de post</th><th>Taxonomia editable en columna</th><th>Estado</th></tr></thead><tbody>';

            foreach ( $post_types as $post_type ) {
                $taxonomies = get_object_taxonomies( $post_type->name, 'objects' );
                $eligible = array();

                foreach ( $taxonomies as $tax_obj ) {
                    if ( ! empty( $tax_obj->show_ui ) && ! empty( $tax_obj->show_admin_column ) ) {
                        $eligible[] = $tax_obj;
                    }
                }

                $selected = isset( $saved[ $post_type->name ] ) ? $saved[ $post_type->name ] : '';

                echo '<tr>';
                echo '<td><strong>' . esc_html( $post_type->labels->singular_name ) . '</strong><br><code>' . esc_html( $post_type->name ) . '</code></td>';
                echo '<td>';
                echo '<select name="' . esc_attr( self::OPTION_KEY ) . '[' . esc_attr( $post_type->name ) . ']" style="min-width: 260px">';
                echo '<option value="">Desactivado</option>';

                foreach ( $eligible as $tax_obj ) {
                    echo '<option value="' . esc_attr( $tax_obj->name ) . '" ' . selected( $selected, $tax_obj->name, false ) . '>';
                    echo esc_html( $tax_obj->labels->singular_name . ' (' . $tax_obj->name . ')' );
                    echo '</option>';
                }

                echo '</select>';
                echo '</td>';

                if ( empty( $eligible ) ) {
                    echo '<td><span style="color:#b32d2e">Sin taxonomias elegibles (activa show_admin_column en la taxonomia)</span></td>';
                } else {
                    echo '<td><span style="color:#2271b1">OK</span></td>';
                }

                echo '</tr>';
            }

            echo '</tbody></table>';
        }

        public function render_settings_page() {
            if ( ! current_user_can( 'manage_options' ) ) {
                return;
            }

            echo '<div class="wrap">';
            echo '<h1>Taxonomy Inline Dropdown</h1>';
            echo '<form method="post" action="options.php">';
            settings_fields( 'watid_settings_group' );
            do_settings_sections( 'watid-settings' );
            submit_button( 'Guardar configuracion' );
            echo '</form>';
            echo '</div>';
        }

        public function enqueue_admin_assets( $hook_suffix ) {
            if ( 'edit.php' !== $hook_suffix ) {
                return;
            }

            $screen = get_current_screen();
            if ( ! $screen || empty( $screen->post_type ) ) {
                return;
            }

            $mapping = $this->get_mapping();
            $post_type = $screen->post_type;

            if ( empty( $mapping[ $post_type ] ) ) {
                return;
            }

            $taxonomy = $mapping[ $post_type ];
            $tax_obj = get_taxonomy( $taxonomy );
            if ( ! $tax_obj || empty( $tax_obj->show_admin_column ) ) {
                return;
            }

            if ( ! current_user_can( 'edit_posts' ) ) {
                return;
            }

            $terms = get_terms(
                array(
                    'taxonomy' => $taxonomy,
                    'hide_empty' => false,
                )
            );

            if ( is_wp_error( $terms ) ) {
                return;
            }

            $terms_payload = array();
            foreach ( $terms as $term ) {
                $terms_payload[] = array(
                    'id' => (int) $term->term_id,
                    'name' => $term->name,
                );
            }

            $handle = 'watid-inline-dropdown';
            wp_register_script( $handle, '', array( 'jquery' ), '1.0.0', true );
            wp_enqueue_script( $handle );

            $column_key = 'taxonomy-' . $taxonomy;
            $placeholder = 'Seleccionar ' . ( ! empty( $tax_obj->labels->singular_name ) ? $tax_obj->labels->singular_name : $taxonomy );

            $data = array(
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'postType' => $post_type,
                'taxonomy' => $taxonomy,
                'columnClass' => 'column-' . $column_key,
                'terms' => $terms_payload,
                'placeholder' => $placeholder,
                'fetchNonce' => wp_create_nonce( self::NONCE_ACTION_FETCH ),
                'saveNonce' => wp_create_nonce( self::NONCE_ACTION_SAVE ),
            );

            wp_add_inline_script( $handle, 'window.WATID = ' . wp_json_encode( $data ) . ';', 'before' );

            $script = <<<'JS'
(function($){
    function getPostIds() {
        var ids = [];
        $('#the-list tr[id^="post-"]').each(function(){
            var rowId = $(this).attr('id') || '';
            var postId = parseInt(rowId.replace('post-', ''), 10);
            if (!isNaN(postId) && postId > 0) {
                ids.push(postId);
            }
        });
        return ids;
    }

    function buildSelect(currentTermId) {
        var select = $('<select class="watid-inline-term-select" style="min-width:180px"></select>');
        select.append($('<option></option>').val('').text(WATID.placeholder));

        (WATID.terms || []).forEach(function(term){
            var opt = $('<option></option>').val(String(term.id)).text(term.name);
            if (String(term.id) === String(currentTermId || '')) {
                opt.prop('selected', true);
            }
            select.append(opt);
        });

        return select;
    }

    function renderDropdowns(currentMap) {
        $('#the-list tr[id^="post-"]').each(function(){
            var $row = $(this);
            var rowId = $row.attr('id') || '';
            var postId = parseInt(rowId.replace('post-', ''), 10);
            if (!postId) {
                return;
            }

            var $cell = $row.find('td.' + WATID.columnClass);
            if (!$cell.length) {
                return;
            }

            var current = currentMap && currentMap[String(postId)] ? currentMap[String(postId)] : '';
            var $select = buildSelect(current);

            $select.on('change', function(){
                var termId = $(this).val();
                var $thisSelect = $(this);
                $thisSelect.prop('disabled', true);

                $.post(WATID.ajaxUrl, {
                    action: 'watid_set_term',
                    nonce: WATID.saveNonce,
                    post_id: postId,
                    taxonomy: WATID.taxonomy,
                    term_id: termId
                }).done(function(resp){
                    if (!resp || !resp.success) {
                        var msg = resp && resp.data && resp.data.message ? resp.data.message : 'No se pudo guardar el termino';
                        alert(msg);
                    }
                }).fail(function(){
                    alert('Error de conexion al guardar el termino');
                }).always(function(){
                    $thisSelect.prop('disabled', false);
                });
            });

            $cell.empty().append($select);
        });
    }

    function initInlineTaxonomyDropdown() {
        if (!window.WATID || !WATID.taxonomy || !WATID.postType) {
            return;
        }

        var postIds = getPostIds();
        if (!postIds.length) {
            return;
        }

        $.post(WATID.ajaxUrl, {
            action: 'watid_get_current_terms',
            nonce: WATID.fetchNonce,
            post_type: WATID.postType,
            taxonomy: WATID.taxonomy,
            post_ids: postIds
        }).done(function(resp){
            if (resp && resp.success && resp.data && resp.data.current_terms) {
                renderDropdowns(resp.data.current_terms);
                return;
            }
            renderDropdowns({});
        }).fail(function(){
            renderDropdowns({});
        });
    }

    $(document).ready(initInlineTaxonomyDropdown);
})(jQuery);
JS;
            wp_add_inline_script( $handle, $script );
        }

        public function ajax_get_current_terms() {
            check_ajax_referer( self::NONCE_ACTION_FETCH, 'nonce' );

            if ( ! current_user_can( 'edit_posts' ) ) {
                wp_send_json_error( array( 'message' => 'Permisos insuficientes' ), 403 );
            }

            $post_type = isset( $_POST['post_type'] ) ? sanitize_key( wp_unslash( $_POST['post_type'] ) ) : '';
            $taxonomy = isset( $_POST['taxonomy'] ) ? sanitize_key( wp_unslash( $_POST['taxonomy'] ) ) : '';
            $post_ids = isset( $_POST['post_ids'] ) ? (array) $_POST['post_ids'] : array();

            if ( ! $post_type || ! $taxonomy ) {
                wp_send_json_error( array( 'message' => 'Parametros invalidos' ), 400 );
            }

            $mapping = $this->get_mapping();
            if ( empty( $mapping[ $post_type ] ) || $mapping[ $post_type ] !== $taxonomy ) {
                wp_send_json_error( array( 'message' => 'Taxonomia no habilitada para este tipo de post' ), 400 );
            }

            $result = array();
            foreach ( $post_ids as $raw_post_id ) {
                $post_id = absint( $raw_post_id );
                if ( ! $post_id ) {
                    continue;
                }

                $terms = wp_get_object_terms(
                    $post_id,
                    $taxonomy,
                    array(
                        'fields' => 'ids',
                    )
                );

                if ( is_wp_error( $terms ) || empty( $terms ) ) {
                    $result[ (string) $post_id ] = '';
                } else {
                    $result[ (string) $post_id ] = (string) absint( $terms[0] );
                }
            }

            wp_send_json_success( array( 'current_terms' => $result ) );
        }

        public function ajax_set_term() {
            check_ajax_referer( self::NONCE_ACTION_SAVE, 'nonce' );

            $post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
            $taxonomy = isset( $_POST['taxonomy'] ) ? sanitize_key( wp_unslash( $_POST['taxonomy'] ) ) : '';
            $term_id = isset( $_POST['term_id'] ) ? absint( $_POST['term_id'] ) : 0;

            if ( ! $post_id || ! $taxonomy ) {
                wp_send_json_error( array( 'message' => 'Parametros invalidos' ), 400 );
            }

            if ( ! current_user_can( 'edit_post', $post_id ) ) {
                wp_send_json_error( array( 'message' => 'No tienes permisos para editar este post' ), 403 );
            }

            $post_type = get_post_type( $post_id );
            if ( ! $post_type ) {
                wp_send_json_error( array( 'message' => 'Post no encontrado' ), 404 );
            }

            $mapping = $this->get_mapping();
            if ( empty( $mapping[ $post_type ] ) || $mapping[ $post_type ] !== $taxonomy ) {
                wp_send_json_error( array( 'message' => 'Taxonomia no habilitada para este tipo de post' ), 400 );
            }

            if ( $term_id > 0 ) {
                $term = get_term( $term_id, $taxonomy );
                if ( ! $term || is_wp_error( $term ) ) {
                    wp_send_json_error( array( 'message' => 'Termino invalido para esta taxonomia' ), 400 );
                }
                $set_result = wp_set_object_terms( $post_id, array( $term_id ), $taxonomy, false );
            } else {
                $set_result = wp_set_object_terms( $post_id, array(), $taxonomy, false );
            }

            if ( is_wp_error( $set_result ) ) {
                wp_send_json_error( array( 'message' => $set_result->get_error_message() ), 500 );
            }

            wp_send_json_success( array( 'message' => 'Termino actualizado correctamente' ) );
        }

        private function get_mapping() {
            $mapping = get_option( self::OPTION_KEY, array() );
            return is_array( $mapping ) ? $mapping : array();
        }
    }
}

new WP_Admin_Taxonomy_Inline_Dropdown();
